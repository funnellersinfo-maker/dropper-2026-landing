import BentoGrid from "@/components/BentoGrid";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import Navigation from "@/components/Navigation";
import Pricing from "@/components/Pricing";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";
import Testimonials from "@/components/Testimonials";
import AutomationFunnel from "@/components/AutomationFunnel";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Navigation />
      <main>
        <Hero />
        <BentoGrid />
        <AutomationFunnel />
        <Pricing />
        <FAQ />
        <Testimonials />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
